<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
    <!-- Styles -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/flatpickr.min.css')); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <script src="<?php echo e(asset('chart.js/chart.js')); ?>"></script>
    <script src="<?php echo e(asset('pusher-js/pusher.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/fontawesome/css/all.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        :root {
        --cabecera-color: #334C96;
        --cabecera-letras: white;
        --color-sidebar: #1D2435;
        }
        .cabeceratable {
            background-color:  var(--cabecera-color) ;
            color: var(--cabecera-letras);
        }
        .sidebarcolor {
            background-color: var(--color-sidebar);
            color: var(--cabecera-letras);
        }

    </style>

    <?php echo \Livewire\Livewire::styles(); ?>


    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
     <script src="<?php echo e(asset('js/es.js')); ?>"></script>
    <script src="<?php echo e(asset('js/flatpickr.js')); ?>"></script>
    <script src="<?php echo e(asset('js/rangoPlugin.js')); ?>"></script>



</head>

<body class="font-sans antialiased">

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.banner','data' => []]); ?>
<?php $component->withName('jet-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="min-h-screen bg-gray-100">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-menu')->html();
} elseif ($_instance->childHasBeenRendered('LSFJFA9')) {
    $componentId = $_instance->getRenderedChildComponentId('LSFJFA9');
    $componentTag = $_instance->getRenderedChildComponentTagName('LSFJFA9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LSFJFA9');
} else {
    $response = \Livewire\Livewire::mount('navigation-menu');
    $html = $response->html();
    $_instance->logRenderedChild('LSFJFA9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


        <!-- Page Heading -->
        <?php if(isset($header)): ?>
                <header class="bg-white shadow">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

        <!-- Page Content -->

        <main>

            <div class="md:flex ">
                <div class="w-auto min-w-full md:min-w-0  ">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sidebar', [])->html();
} elseif ($_instance->childHasBeenRendered('LST5phS')) {
    $componentId = $_instance->getRenderedChildComponentId('LST5phS');
    $componentTag = $_instance->getRenderedChildComponentTagName('LST5phS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LST5phS');
} else {
    $response = \Livewire\Livewire::mount('sidebar', []);
    $html = $response->html();
    $_instance->logRenderedChild('LST5phS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
                <div class="w-5/6 min-w-full md:min-w-0">
                <?php echo e($slot); ?>

                </div>
            </div>
        </main>
    </div>


    <?php echo $__env->yieldPushContent('modals'); ?>


    <?php echo \Livewire\Livewire::scripts(); ?>


    <?php echo $__env->yieldPushContent('scripts'); ?>



</body>

</html>
<?php /**PATH C:\Users\Retr023\Desktop\learning_react\Gestion-de-Trabajo-Remoto\resources\views/layouts/app.blade.php ENDPATH**/ ?>