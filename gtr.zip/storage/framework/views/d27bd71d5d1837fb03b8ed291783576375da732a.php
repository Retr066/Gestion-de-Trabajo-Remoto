<div>

    <?php if (isset($component)) { $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table::class, []); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <div class="flex bg-white px-4 py-3  sm:px-6">
            <input wire:model="search" class="form-input rounded-md shadow-sm mt-1 block w-full" type="text"
                placeholder="Buscar...">
            <div class="form-input rounded-md shadow-sm mt-1 ml-6 block ">
                <select wire:model="perPage" class="ouline-none text-gray-500 text-sm">
                    <option value="5">5 por Pagina</option>
                    <option value="10">10 por Pagina</option>
                    <option value="15">15 por Pagina</option>
                    <option value="50">50 por Pagina</option>
                    <option value="100">100 por Pagina</option>
                </select>
            </div>
            <?php if($search !== ''): ?>
                <button wire:click="clear" class="form-input rounded-md shadow px-3 mt-1 ml-6 block">
                    X
                </button>
            <?php endif; ?>

        </div>
        <?php if($informes->count()): ?>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="cabeceratable">
                    <tr>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-medium  uppercase tracking-wider">
                            N°
                            <button wire:click="sortable('id')">
                                <span class="fa fa<?php echo e($camp === 'id' ? $icon : '-circle'); ?>"></span>
                            </button>
                        </th>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-medium  uppercase tracking-wider">
                            N° de Usuario
                            <button wire:click="sortable('id')">
                                <span class="fa fa<?php echo e($camp === 'id' ? $icon : '-circle'); ?>"></span>
                            </button>
                        </th>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-medium  uppercase tracking-wider">
                            Fecha de Rechazo
                            <button wire:click="sortable('updated_at')">
                                <span class="fa fa<?php echo e($camp === 'updated_at' ? $icon : '-circle'); ?>"></span>
                            </button>
                        </th>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-medium  uppercase tracking-wider">
                            MOTIVO
                            <button wire:click="sortable('respuesta')">
                                <span class="fa fa<?php echo e($camp === 'respuesta' ? $icon : '-circle'); ?>"></span>
                            </button>
                        </th>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-medium  uppercase tracking-wider">
                            Estado
                            <button wire:click="sortable('estado')">
                                <span class="fa fa<?php echo e($camp === 'estado' ? $icon : '-circle'); ?>"></span>
                            </button>
                        </th>
                        <th scope="col" class="relative px-6 py-3">
                            <span
                                class="text-left text-xs font-medium  uppercase tracking-wider">Acciones</span>
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">

                    <?php $__currentLoopData = $informes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900"><?php echo e($informe->id); ?></div>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900"><?php echo e($informe->usuario_id); ?></div>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900"><?php echo e($informe->updated_at); ?></div>

                            </td>

                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900"><?php echo e($informe->respuesta); ?></div>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span
                                    class="bg-red-200 text-red-600 py-1 px-3 rounded-full text-xs"><?php echo e($informe->estado_cambiado); ?></span>
                            </td>


                            <td class="flex px-6 py-4 whitespace-nowrap  text-sm font-medium">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Docente read')): ?>
                                    <button wire:click="$emitTo('ver-modal','ShowModal',<?php echo e($informe->id); ?>)"
                                        class=" text-indigo-400 hover:text-indigo-700">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20"
                                            fill="currentColor">
                                            <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                                            <path fill-rule="evenodd"
                                                d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z"
                                                clip-rule="evenodd" />
                                        </svg>
                                    </button>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Docente create')): ?>
                                    <a href="<?php echo e(route('pdf', $informe->id)); ?>" class="text-gray-400 hover:text-gray-700">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20"
                                            fill="currentColor">
                                            <path fill-rule="evenodd"
                                                d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z"
                                                clip-rule="evenodd" />
                                        </svg>
                                    </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Docente update')): ?>
                                    <button wire:click="$emit('editModal',<?php echo e($informe); ?>)"
                                        class="text-yellow-400 hover:text-yellow-700">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20"
                                            fill="currentColor">
                                            <path
                                                d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
                                            <path fill-rule="evenodd"
                                                d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z"
                                                clip-rule="evenodd" />
                                        </svg>
                                    </button>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Docente delete')): ?>
                                    <button onclick="borrarInforme(<?php echo e($informe->id); ?>)"
                                        class="text-red-400 hover:text-red-700">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20"
                                            fill="currentColor">
                                            <path fill-rule="evenodd"
                                                d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                                                clip-rule="evenodd" />
                                        </svg>
                                    </button>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Docente update')): ?>
                                    <button onclick="enviarInforme(<?php echo e($informe->id); ?>)"
                                        class="text-green-400 hover:text-green-700">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20"
                                            fill="currentColor">
                                            <path fill-rule="evenodd"
                                                d="M10.293 15.707a1 1 0 010-1.414L14.586 10l-4.293-4.293a1 1 0 111.414-1.414l5 5a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0z"
                                                clip-rule="evenodd" />
                                            <path fill-rule="evenodd"
                                                d="M4.293 15.707a1 1 0 010-1.414L8.586 10 4.293 5.707a1 1 0 011.414-1.414l5 5a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0z"
                                                clip-rule="evenodd" />
                                        </svg>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- More people... -->
                </tbody>

            </table>

            <div class="bg-white px-4 py-3  border-t border-gray-200 sm:px-6">
                <?php echo e($informes->links()); ?>

            </div>
        <?php else: ?>
            <div class="bg-white px-4 py-3  border-t border-gray-200 text-gray-500 sm:px-6">
                No hay resultados para la Busqueda "<?php echo e($search); ?>" en la pagina <?php echo e($page); ?> al
                mostrar "<?php echo e($perPage); ?>" por Pagina
            </div>
        <?php endif; ?>



     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6)): ?>
<?php $component = $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6; ?>
<?php unset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6); ?>
<?php endif; ?>



</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        function borrarInforme(informe) {
            Swal.fire({
                title: 'Estas Seguro?',
                text: "No habra Vuelta Atras!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, Borralo!'
            }).then((result) => {
                if (result.isConfirmed) {
                    Livewire.emit('deleteInformeList', informe)

                }
            })
        }
        Livewire.on('deleteInforme', (informe) => {
            Swal.fire(
                'Borrado!',
                `El usuario ${informe.id} se borro corrrectamente`,
                'success'
            )
        });

        function enviarInforme(informe) {
            Swal.fire({
                title: 'Estas Seguro de Enviar?',
                text: "No habra Vuelta Atras!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, Borralo!'
            }).then((result) => {
                if (result.isConfirmed) {
                    Livewire.emit('enviarInforme', informe)

                }
            })
        }
        Livewire.on('listEnviar', (informe) => {
            Swal.fire(
                'Enviado!',
                `El reporte ${informe.id} se envio corrrectamente`,
                'success'
            )
        });

        function abrirInforme() {
            Swal.fire({
                title: 'Nuevo Informe?',
                text: "Desea Crear un Nuevo Informe!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, Crealo!'
            }).then((result) => {
                if (result.isConfirmed) {
                    Livewire.emit('abrirModal')

                }
            })
        };

    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\Retr023\Desktop\learning_react\Gestion-de-Trabajo-Remoto\resources\views/livewire/rechazado-table.blade.php ENDPATH**/ ?>