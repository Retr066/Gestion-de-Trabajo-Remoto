<div>
    <form wire:submit.prevent='<?php echo e($method); ?>'>
        <?php if (isset($component)) { $__componentOriginal4fdbfa6fc4b83ec56118445f4db0014d2c5240e5 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ComponentModal::class, ['showModal' => $showModal,'action' => $action]); ?>
<?php $component->withName('component-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="md:w-full mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                    <?php echo e($nombreModal); ?>

                </h3>
                <div class="mt-5 -mx-3 md:flex mb-3 flex-col justify-center items-around">
                    <div class="md:w-full px-3  mb-6">
                        <label class="block uppercase tracking-wide text-grey-darker text-xs font-bold mb-2"
                            for="grid-zip">
                            Detalle el Motivo de Rechazo del Informe </label>
                        <textarea wire:model="respuesta"
                            class="w-full px-3 py-2 text-gray-700 border rounded-lg focus:outline-none"
                            rows="4"></textarea>
                        <?php $__errorArgs = ['respuesta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-red-700"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fdbfa6fc4b83ec56118445f4db0014d2c5240e5)): ?>
<?php $component = $__componentOriginal4fdbfa6fc4b83ec56118445f4db0014d2c5240e5; ?>
<?php unset($__componentOriginal4fdbfa6fc4b83ec56118445f4db0014d2c5240e5); ?>
<?php endif; ?>
    </form>
</div>
<?php /**PATH C:\Users\Retr023\Desktop\learning_react\Gestion-de-Trabajo-Remoto\resources\views/livewire/modal-rechazo.blade.php ENDPATH**/ ?>