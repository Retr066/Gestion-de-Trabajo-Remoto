<div>

    <div class="border border-gray-300 p-6 grid grid-cols-1 gap-6 bg-white shadow-lg rounded-lg m-3">
        <div class="flex flex-col items-center">

            <div class="w-full md:w-1/2 flex flex-col items-center">
                <div class="w-full px-4">
                    <div class="flex flex-col items-center relative">
                        <?php if($picked): ?>
                            <span class="bg-green-200 text-green-600 py-1 px-3 rounded-full text-xs">Seleccionado</span>
                        <?php else: ?>
                            <span class="bg-red-200 text-red-600 py-1 px-3 rounded-full text-xs">Sin Seleccionar</span>
                        <?php endif; ?>
                        <div class="w-full">
                            <div class="my-2 p-1 bg-white flex border border-gray-200 rounded">
                                <div class="flex flex-auto flex-wrap"></div>
                                <input wire:model="buscar" wire:keydown.enter="asignarPrimero()"
                                    placeholder="Buscar Docentes... "
                                    class="p-1 px-2 appearance-none outline-none w-full text-gray-800">

                                <div
                                    class="text-gray-300 w-8 py-1 pl-2 pr-1 border-l flex items-center border-gray-200">
                                    <button wire:click="restablecer()"
                                        class="cursor-pointer w-6 h-6 text-gray-600 outline-none focus:outline-none">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
                                            viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php $__errorArgs = ['buscar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-red-700"><?php echo e($message); ?></span>
                        <?php else: ?>
                            <?php if(count($usuarios) > 0): ?>
                                <?php if(!$picked): ?>
                                    <div
                                        class=" shadow bg-white top-100 z-40 w-full lef-0 rounded max-h-select overflow-y-auto svelte-5uyqqj">
                                        <div class="flex flex-col w-full">
                                            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div
                                                    class="cursor-pointer w-full border-gray-100 border-b hover:bg-teal-100">
                                                    <div wire:click="asignarUsuario('<?php echo e($usuario->name); ?> <?php echo e($usuario->lastname); ?>',<?php echo e($usuario->id); ?>)"
                                                        class="flex w-full items-center p-2 pl-2 border-transparent border-l-2 relative hover:border-teal-100">
                                                        <div class="w-6 flex flex-col items-center">
                                                            <?php if($usuario->profile_photo_path == null): ?>
                                                                <div
                                                                    class="flex relative w-10 h-10 bg-orange-500 justify-center items-center m-1 mr-2 w-4 h-4 mt-1 rounded-full ">
                                                                    <img class="rounded-full"
                                                                        src="<?php echo e($usuario->image_user); ?>"
                                                                        alt="<?php echo e($usuario->name); ?> ">
                                                                </div>
                                                            <?php else: ?>
                                                                <div
                                                                    class="flex relative w-10 h-10 bg-orange-500 justify-center items-center m-1 mr-2 w-4 h-4 mt-1 rounded-full ">
                                                                    <img class="rounded-full" alt="<?php echo e($usuario->name); ?>"
                                                                        src="<?php echo e(asset('storage/' . $usuario->profile_photo_path)); ?>">
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="w-full items-center flex">
                                                            <div class="mx-2 -mt-1  "><?php echo e($usuario->name); ?>

                                                                <?php echo e($usuario->lastname); ?>

                                                                <div
                                                                    class="text-xs truncate w-full normal-case font-normal -mt-1 text-gray-500">
                                                                    <?php echo e($usuario->r_area->nombre_area); ?></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php elseif($buscar !== '' && count($usuarios) >= 0 ): ?>
                                <small class="form-text text-muted">Docente no encontrado</small>
                            <?php else: ?>
                                <small class="form-text text-muted">Comienza a buscar a los Docente (*)</small>

                            <?php endif; ?>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="flex flex-wrap -mx-3 mb-6">
            <div class="w-full md:w-1/2 px-3">
                <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-last-name">
                    Seleccione Actividades Planificadas
                </label>
                <select id="input4" wire:model="informe_planificado"
                    class="block appearance-none w-full bg-gray-200 border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500">
                    <option value="" selected>Seleccione... </option>
                    <?php $__currentLoopData = $this->informes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($informe->id); ?>">
                            <?php echo e($informe->fecha_inicio_planificadas); ?>/<?php echo e($informe->fecha_fin_planificadas); ?>

                            enviado:
                            <?php echo e($informe->updated_at); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['informe_planificado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-red-700"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-first-name">
                    Seleccione Actividades Realizadas
                </label>
                <select wire:model="informe_realizado" id="input4"
                    class="block appearance-none w-full bg-gray-200 border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500">
                    <option value="" selected>Seleccione... </option>
                    <?php $__currentLoopData = $this->informes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($informe->id); ?>">
                            <?php echo e($informe->fecha_inicio_realizadas); ?>/<?php echo e($informe->fecha_fin_realizadas); ?> enviado:
                            <?php echo e($informe->updated_at); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['informe_realizado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-red-700"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="flex justify-center"><button wire:click="generarComparacion()"
                class="cabeceratable p-2 border md:w-1/4 w-full rounded-md bg-gray-800 text-white">Generar
                Comparacion</button></div>
        <?php if(session()->has('message')): ?>
            <div class="alert alert-danger bg-red-200 text-red-800 text-center">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </div>
    <!--Third  card-->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-2">

        <!--desde aqui -->

        <div class="p-8 bg-white">
            <!--Banner image-->

            <!--Tag-->
            <p class="text-indigo-500 font-semibold text-base mt-2"><?php echo e($nombre2); ?></p>

            <!--Title-->
            <?php $__currentLoopData = $data_planificado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planificado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h1 class="font-semibold text-gray-900 leading-none text-xl mt-1 capitalize truncate">
                    <?php echo e($planificado->nombre_rubro_planificadas); ?>

                </h1>
                <!--Description-->
                <div class="max-w-full">
                    <p class="text-base font-medium tracking-wide text-gray-600 mt-1">
                        <?php echo e($planificado->descripcion_rubro_planificadas); ?>

                    </p>
                    <p class="text-base font-medium tracking-wide text-gray-600 mt-1">
                        Horas empleadas en la actividad:<?php echo e($planificado->horas_solas_planificas); ?>

                    </p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="flex items-center space-x-2 mt-20">
                <!--Author's profile photo-->

                <?php $__currentLoopData = $this->user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user->profile_photo_path == null): ?>
                        <img class="w-10 h-10 object-cover object-center rounded-full" src="<?php echo e($user->image_user); ?>"
                            alt="<?php echo e($user->name); ?> " />
                    <?php else: ?>
                        <img class="w-10 h-10 object-cover object-center rounded-full" alt="<?php echo e($user->name); ?>"
                            src="<?php echo e(asset('storage/' . $user->profile_photo_path)); ?>" />
                    <?php endif; ?>
                    <div>
                        <!--Author name-->
                        <p class="text-gray-900 font-semibold"><?php echo e($user->name); ?> <?php echo e($user->lastname); ?></p>
                        <p class="text-gray-500 font-semibold text-sm">
                            Fecha <?php echo e($fecha_envio_planificada); ?>; Horas Total:<?php echo e($horas_planificadas); ?>

                        </p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!--segundo -->

        <div class="p-8 bg-white">

            <p class="text-indigo-500 font-semibold text-base mt-2"><?php echo e($nombre); ?></p>

            <!--Title-->
            <?php $__currentLoopData = $data_realizado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $realizado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h1 class="font-semibold text-gray-900 leading-none text-xl mt-1 capitalize truncate">
                    <?php echo e($realizado->nombre_rubro_realizadas); ?>

                </h1>
                <!--Description-->
                <div class="max-w-full">
                    <p class="text-base font-medium tracking-wide text-gray-600 mt-1">
                        <?php echo e($realizado->descripcion_rubro_realizadas); ?>

                    </p>
                    <p class="text-base font-medium tracking-wide text-gray-600 mt-1">
                        Horas empleadas en la actividad:<?php echo e($realizado->horas_solas_realizadas); ?>

                    </p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="flex items-center space-x-2 mt-20">
                <!--Author's profile photo-->
                <?php $__currentLoopData = $this->user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user->profile_photo_path == null): ?>
                        <img class="w-10 h-10 object-cover object-center rounded-full" src="<?php echo e($user->image_user); ?>"
                            alt="<?php echo e($user->name); ?> " />
                    <?php else: ?>
                        <img class="w-10 h-10 object-cover object-center rounded-full" alt="<?php echo e($user->name); ?>"
                            src="<?php echo e(asset('storage/' . $user->profile_photo_path)); ?>" />
                    <?php endif; ?>
                    <div>
                        <!--Author name-->
                        <p class="text-gray-900 font-semibold"><?php echo e($user->name); ?> <?php echo e($user->lastname); ?></p>
                        <p class="text-gray-500 font-semibold text-sm">
                            Fecha <?php echo e($fecha_envio_realizada); ?>; Horas Total:<?php echo e($horas_realizas); ?>

                        </p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!--hasta aqui-->

    </div>
</div>
<?php $__env->startPush('styles'); ?>
    <style>
        .top-100 {
            top: 100%
        }

        .bottom-100 {
            bottom: 100%
        }

        .max-h-select {
            max-height: 300px;
        }

    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\Retr023\Desktop\learning_react\Gestion-de-Trabajo-Remoto\resources\views/livewire/comparar.blade.php ENDPATH**/ ?>