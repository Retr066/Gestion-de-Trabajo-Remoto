<div>
    <td class="px-4 py-3 "><?php echo e($slot); ?></td>
</div>
<?php /**PATH C:\Users\Retr023\Desktop\learning_react\Gestion-de-Trabajo-Remoto\resources\views/components/component-td.blade.php ENDPATH**/ ?>