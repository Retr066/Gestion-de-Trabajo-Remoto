
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

        <h2 class="text-center mt-8 tracking-widest font-semibold text-2xl">
            REPORTES ESTADISTICOS DE LAS ACTIVIDADES
        </h2>
        <div class="py-12 px-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-1">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('reportesdocente', [])->html();
} elseif ($_instance->childHasBeenRendered('7ulrk4y')) {
    $componentId = $_instance->getRenderedChildComponentId('7ulrk4y');
    $componentTag = $_instance->getRenderedChildComponentTagName('7ulrk4y');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7ulrk4y');
} else {
    $response = \Livewire\Livewire::mount('reportesdocente', []);
    $html = $response->html();
    $_instance->logRenderedChild('7ulrk4y', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Retr023\Desktop\learning_react\Gestion-de-Trabajo-Remoto\resources\views/docente/reportes.blade.php ENDPATH**/ ?>