<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="py-12 px-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-1">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">

                <div class="mx-3 my-3">
                    <div class="md:w-full md:flex lg:flex xl:flex 2xl:flex overflow-hidden shadow-xl sm:rounded-lg " style="background-color: #b3c6ff ;">
                        <div class="md:p-4 md:w-6/12 lg:w-6/12 xl:w-6/12 2xl:w-6/12">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("chat-form")->html();
} elseif ($_instance->childHasBeenRendered('N5BHTVI')) {
    $componentId = $_instance->getRenderedChildComponentId('N5BHTVI');
    $componentTag = $_instance->getRenderedChildComponentTagName('N5BHTVI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('N5BHTVI');
} else {
    $response = \Livewire\Livewire::mount("chat-form");
    $html = $response->html();
    $_instance->logRenderedChild('N5BHTVI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                        <div class="md:p-4 md:w-6/12 lg:w-6/12 xl:w-6/12 2xl:w-6/12 md:block lg:block xl:block 2xl:block " style="overflow: auto; height: 440px;" >
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("chat-list")->html();
} elseif ($_instance->childHasBeenRendered('RIB46k7')) {
    $componentId = $_instance->getRenderedChildComponentId('RIB46k7');
    $componentTag = $_instance->getRenderedChildComponentTagName('RIB46k7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RIB46k7');
} else {
    $response = \Livewire\Livewire::mount("chat-list");
    $html = $response->html();
    $_instance->logRenderedChild('RIB46k7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Retr023\Desktop\learning_react\Gestion-de-Trabajo-Remoto\resources\views/jefatura/chat.blade.php ENDPATH**/ ?>