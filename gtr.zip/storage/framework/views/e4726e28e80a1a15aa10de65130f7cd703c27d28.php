<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <h2 class="text-center mt-8">INFORMES DE ACTIVIDADES RECHAZADOS</h2>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('rechazado-table', [])->html();
} elseif ($_instance->childHasBeenRendered('EAT9xV9')) {
    $componentId = $_instance->getRenderedChildComponentId('EAT9xV9');
    $componentTag = $_instance->getRenderedChildComponentTagName('EAT9xV9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EAT9xV9');
} else {
    $response = \Livewire\Livewire::mount('rechazado-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('EAT9xV9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
    <?php $__env->startPush('modals'); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('modal', [])->html();
} elseif ($_instance->childHasBeenRendered('qLDFlU2')) {
    $componentId = $_instance->getRenderedChildComponentId('qLDFlU2');
    $componentTag = $_instance->getRenderedChildComponentTagName('qLDFlU2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qLDFlU2');
} else {
    $response = \Livewire\Livewire::mount('modal', []);
    $html = $response->html();
    $_instance->logRenderedChild('qLDFlU2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopPush(); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('ver-modal', [])->html();
} elseif ($_instance->childHasBeenRendered('fwpHW2X')) {
    $componentId = $_instance->getRenderedChildComponentId('fwpHW2X');
    $componentTag = $_instance->getRenderedChildComponentTagName('fwpHW2X');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fwpHW2X');
} else {
    $response = \Livewire\Livewire::mount('ver-modal', []);
    $html = $response->html();
    $_instance->logRenderedChild('fwpHW2X', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Retr023\Desktop\learning_react\Gestion-de-Trabajo-Remoto\resources\views/docente/informesRechazados.blade.php ENDPATH**/ ?>