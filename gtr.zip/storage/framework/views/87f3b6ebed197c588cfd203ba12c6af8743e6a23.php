<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <h2 class="text-center mt-8">ACTIVIDADES DESARROLLADAS DE LOS DOCENTES</h2>
    <div class="py-12 px-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-1">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('jefatura-table', [])->html();
} elseif ($_instance->childHasBeenRendered('d4QbvkZ')) {
    $componentId = $_instance->getRenderedChildComponentId('d4QbvkZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('d4QbvkZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('d4QbvkZ');
} else {
    $response = \Livewire\Livewire::mount('jefatura-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('d4QbvkZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>

    <?php $__env->startPush('modals'); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('ver-modal', [])->html();
} elseif ($_instance->childHasBeenRendered('fMJjD5Y')) {
    $componentId = $_instance->getRenderedChildComponentId('fMJjD5Y');
    $componentTag = $_instance->getRenderedChildComponentTagName('fMJjD5Y');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fMJjD5Y');
} else {
    $response = \Livewire\Livewire::mount('ver-modal', []);
    $html = $response->html();
    $_instance->logRenderedChild('fMJjD5Y', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php $__env->stopPush(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('modal-rechazo', [])->html();
} elseif ($_instance->childHasBeenRendered('JFO2aWZ')) {
    $componentId = $_instance->getRenderedChildComponentId('JFO2aWZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('JFO2aWZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JFO2aWZ');
} else {
    $response = \Livewire\Livewire::mount('modal-rechazo', []);
    $html = $response->html();
    $_instance->logRenderedChild('JFO2aWZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Retr023\Desktop\learning_react\Gestion-de-Trabajo-Remoto\resources\views/jefatura/informesJefatura.blade.php ENDPATH**/ ?>