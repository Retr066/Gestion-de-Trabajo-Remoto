<div >

    <div class="md:w-full md:p-3 md:pb-0 text-gray-500 font-bold text-3xl tracking-wider">
    Últimos mensajes
    </div>

    <?php $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        <?php if($mensaje["recibido"]): ?>
            <div class="sidebarcolor block  px-2 py-1 max-w-sm mx-auto rounded-lg shadow-lg float-left m-2">
                <div class="break-words">
                    <span class="text-base  font-medium" ><?php echo e($mensaje["mensaje"]); ?></span>
                </div>
                <div class="flex justify-between items-center">
                    <div class="flex items-center">
                        <?php if($mensaje["profile_photo_path"] == null): ?>
                        <img class="w-8 h-8 object-cover rounded-full"
                            src="<?php echo e($mensaje["profile_photo_url"]); ?>" alt="<?php echo e($mensaje["usuario"]); ?> ">
                                     <?php else: ?>
                                  <img class="w-8 h-8 object-cover rounded-full"
                                   src="<?php echo e(asset('storage/' . $mensaje["profile_photo_path"])); ?>"
                               alt="<?php echo e($mensaje["usuario"]); ?> ">
                            <?php endif; ?>
                        <span class=" text-sm mx-3" ><?php echo e($mensaje["usuario"]); ?> <span class="font-black italic text-xs "><?php echo e($mensaje['rol']); ?></span></span>

                    </div>
                    <span class="font-light text-sm "><?php echo e($mensaje["fecha"]); ?></span>
                </div>
            </div>
        <?php else: ?>
        <div class=" block bg-white  px-2 py-1 max-w-sm mx-auto rounded-lg shadow-lg float-right m-2">
            <div class="break-words">
                <span class="text-base  text-gray-600 font-medium"><?php echo e($mensaje["mensaje"]); ?></span>
            </div>
            <div class="flex justify-between items-center">
                <div class="flex items-center">
                    <?php if($mensaje["profile_photo_path"] == null): ?>
                        <img class="w-8 h-8 object-cover rounded-full"
                            src="<?php echo e($mensaje["profile_photo_url"]); ?>" alt="<?php echo e($mensaje["usuario"]); ?> ">

                                     <?php else: ?>
                                  <img class="w-8 h-8 object-cover rounded-full"
                                   src="<?php echo e(asset('storage/' . $mensaje["profile_photo_path"])); ?>"
                               alt="<?php echo e($mensaje["usuario"]); ?> ">
                            <?php endif; ?>
                    <span class=" text-sm mx-3 text-gray-600" ><?php echo e($mensaje["usuario"]); ?> <span class="font-black italic text-xs "><?php echo e($mensaje['rol']); ?></span></span>
                </div>
                <span class="font-light text-sm text-gray-600 "><?php echo e($mensaje["fecha"]); ?></span>
            </div>
        </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




</div>
<?php $__env->startPush('scripts'); ?>
     <script>
         // Enable pusher logging - don't include this in production
        Pusher.logToConsole = true;
  var pusher = new Pusher('<?php echo e(env('PUSHER_APP_KEY')); ?>', {
      cluster: '<?php echo e(env('PUSHER_APP_CLUSTER')); ?>',
      forceTLS: true
  });

  var channel = pusher.subscribe('chat-channel');

  channel.bind('chat-event', function(data) {
      window.livewire.emit('mensajeRecibido', data);
  });

  setTimeout(function(){ window.livewire.emit('solicitaUsuario'); }, 100);
     </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\Retr023\Desktop\learning_react\Gestion-de-Trabajo-Remoto\resources\views/livewire/chat-list.blade.php ENDPATH**/ ?>