<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <h2 class="text-center mt-8">INFORMES DE ACTIVIDADES</h2>
    <div class="py-12 px-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-1">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('informe-table', [])->html();
} elseif ($_instance->childHasBeenRendered('8GTj1Ff')) {
    $componentId = $_instance->getRenderedChildComponentId('8GTj1Ff');
    $componentTag = $_instance->getRenderedChildComponentTagName('8GTj1Ff');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8GTj1Ff');
} else {
    $response = \Livewire\Livewire::mount('informe-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('8GTj1Ff', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>

    <?php $__env->startPush('modals'); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('modal', [])->html();
} elseif ($_instance->childHasBeenRendered('1MCbsm4')) {
    $componentId = $_instance->getRenderedChildComponentId('1MCbsm4');
    $componentTag = $_instance->getRenderedChildComponentTagName('1MCbsm4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1MCbsm4');
} else {
    $response = \Livewire\Livewire::mount('modal', []);
    $html = $response->html();
    $_instance->logRenderedChild('1MCbsm4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopPush(); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('ver-modal', [])->html();
} elseif ($_instance->childHasBeenRendered('kjgX2Ab')) {
    $componentId = $_instance->getRenderedChildComponentId('kjgX2Ab');
    $componentTag = $_instance->getRenderedChildComponentTagName('kjgX2Ab');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kjgX2Ab');
} else {
    $response = \Livewire\Livewire::mount('ver-modal', []);
    $html = $response->html();
    $_instance->logRenderedChild('kjgX2Ab', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Retr023\Desktop\learning_react\Gestion-de-Trabajo-Remoto\resources\views/docente/informes.blade.php ENDPATH**/ ?>