<div>
    <td class="px-4 py-3 ">{{ $slot }}</td>
</div>
